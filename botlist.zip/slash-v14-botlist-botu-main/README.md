<div align="center">
    <h1>Developed with 💙 by Lourity</h1>
</div>

# 📜 Kullanım
> Install packages. \
> $ `npm install`
>
> Start \
> $ `node index.js`

# 🔒 License
> MIT

# ⭐ Star
> Beğendiyseniz star atmayı unutmayın!


# PAYLAŞILMASI KESİNLİKLE YASAKTIR!!
![spoiler1](https://user-images.githubusercontent.com/96919081/193471008-0a071a3a-90dc-4726-8c78-364ceebcb843.png)
![spoiler2](https://user-images.githubusercontent.com/96919081/193471010-be4469b6-cd5b-4411-88da-3bc4bd554e69.png)
